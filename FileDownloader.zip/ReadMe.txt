ReadMe.txt ----
Author - Sidharth Mishra
San Jose State University '18




//////////////////////////////////////////////////
Steps for running the executable jar to download files to desired location ---

1) Place the FileDownloader.jar and path.properties files in the same location.
2) Edit the BASE_URL and OUTPUT_PATH values to suit your purposes.
BASE_URL is the base URL to the website from where you are downloading the files from.
OUTPUT_PATH is the path to where the output/downloaded files are written to.
For eg- BASE_URL=http://xanadu.cs.sjsu.edu/~drtylin/classes/cs157A/Project/Crawler/Metadata/
OUTPUT_PATH=/Users/charmander/Downloads/DownloadedFiles

Note - The OUTPUT_PATH should be upto the directory name only, in the example above, the DownloadedFiles is the folder(directory) inside which downloaded files are stored or written.

3) Open up console/terminal at the location and type in java -jar FileDownloader.jar and it should download all the files from the website mentioned.


Done! 